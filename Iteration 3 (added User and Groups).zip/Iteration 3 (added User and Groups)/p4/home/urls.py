from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('History/', views.history, name='history'),
    path('Contact/', views.contact, name='contact'),
    path('Contribute/', views.contribute, name='contribute'),
    path('Map/', views.map, name='map'),
    path('PrivacyPolicy/', views.privacyPolicy, name='privacyPolicy'),
    path('TermsOfService/', views.termsOfService, name='termsOfService'),
    path('TheMaking/', views.theMaking, name='theMaking'),

]
