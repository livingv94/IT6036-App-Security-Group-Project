# from django.contrib.auth import logout as django_logout
# from django.contrib.auth.decorators import login_required
# from django.http import Http404, HttpResponse
from django.shortcuts import render

# from django.views import generic

# from .models import Agent, Tour

# @login_required(login_url='/accounts/login/')


def home(request):
    meta = {
        'title': 'Home',
        'description': 'Parkafreebia II home page where you can see a quick rundown of the page and its features'
    }
    return render(request, 'home.html', meta)


def history(request):
    meta = {
        'title': 'History',
        'description': 'Parkafreebia II a short history of the app and the prosess that created it'
    }
    return render(request, 'aboutHistory.html', meta)


def contact(request):
    meta = {
        'title': 'Contact Us',
        'description': 'Parkafreebia II contact page, the form used to submit reviews and bug reports'
    }
    return render(request, 'contactUs.html', meta)


def contribute(request):
    meta = {
        'title': 'Contribute',
        'description': 'Parkafreebia II contributers page where you go to get the app development kit'
    }
    return render(request, 'contribute.html', meta)


def map(request):
    meta = {
        'title': 'Map',
        'description': 'Parkafreebia II map page where you go to see free parks in your area without access to the app'
    }
    return render(request, 'map.html', meta)


def privacyPolicy(request):
    meta = {
        'title': 'Privacy Policy',
        'description': 'Parkafreebia II privacy policy page updated 21st august 2018'
    }
    return render(request, 'privacyPolicy.html', meta)


def termsOfService(request):
    meta = {
        'title': 'Terms of Service',
        'description': 'Parkafreebia II terms of service page updated august 21st 2018'
    }
    return render(request, 'termsOfService.html', meta)


def theMaking(request):
    meta = {
        'title': 'The Making',
        'description': 'Parkafreebia II information on the making of the app and how it was coded'
    }
    return render(request, 'theMaking.html', meta)

#
#
# def tour_detail(request, id):
#     try:
#         tour = Tour.objects.get(id=id)
#     except Tour.DoesNotExist:
#         raise Http404('Tour not found')
#     return render(request, 'tour_detail.html', {'tour': tour})
#
#
# def agent_detail(request, id):
#     try:
#         tour = Agent.objects.get(id=id)
#     except Agent.DoesNotExist:
#         raise Http404('Tour not found')
#     return render(request, 'agent_detail.html', {'agent': agent})
#
#
# def login(request):
#     return render(request, 'login.html')
#
#
# def logout(request):
#     django_logout(request)
#     return render(request, 'logged_out.html')
#
#
# @login_required
# def reset_request(request):
#     # some code here to send an email - not relevant to this assessment.
#     log.warning('Password change request made for {name}'.format(
#         name=request.user.username
#     ))
#     return render(request, 'reset_request.html', {'user': request.user})
#
#
# class TourListView(generic.ListView):
#     model = Tour
#     paginate_by = 10
#
#
# class TourListView2(generic.ListView):
#     model = Tour
#     paginate_by = 10
#
#
# class TourListView2(generic.ListView):
#     """Generic class-based view listing all books on loan. Only visible to users with can_mark_returned permission."""
#     model = Tour
#     template_name = 'home/bookinstance_list_borrowed_all.html'
#     paginate_by = 10
#
#
# class AgentListView(generic.ListView):
#     model = Agent
#     paginate_by = 10
#
#
# class TourDetailView(generic.DetailView):
#     model = Tour
#
#
# class AgentDetailView(generic.DetailView):
#     model = Agent
