from django.urls import path

from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('History/', views.history, name='history'),
    path('Contact/', views.contact, name='contact'),
    path('Contribute/', views.contribute, name='contribute'),
    path('Map/', views.map, name='map'),
    path('PrivacyPolicy/', views.privacyPolicy, name='privacyPolicy'),
    path('TermsOfService/', views.termsOfService, name='termsOfService'),
    path('TheMaking/', views.theMaking, name='theMaking'),
    # path('tours2/', views.TourListView2.as_view(), name='tours2'),
    # path('agents/', views.AgentListView.as_view(), name = 'agents'),
    # path('tour/<int:pk>', views.TourDetailView.as_view(), name='tour_detail'),
    # path('agent/<int:pk>', views.AgentDetailView.as_view(), name='agent_detail'),

]
